export interface SimulationConfig {
  tlbSize: number;
  memoryAccessTime: number;
  tlbAccessTime: number;
  referenceString: string;
  replacementPolicy: 'FIFO' | 'LRU';
}

export interface AccessDetail {
  accessNumber: number;
  pageNumber: number;
  isHit: boolean;
}

export interface SimulationResult {
  config: SimulationConfig;
  hitRate: number;
  missRate: number;
  emat: number;
  totalAccesses: number;
  hits: number;
  misses: number;
  accessDetails: AccessDetail[];
}

export interface SimulationLog {
  id: string;
  timestamp: string;
  config: SimulationConfig;
  hitRate: number;
  emat: number;
}
