import { SimulationConfig, SimulationResult, AccessDetail } from '../types';

export function runSimulation(config: SimulationConfig): SimulationResult {
  const { tlbSize, memoryAccessTime, tlbAccessTime, referenceString, replacementPolicy } = config;

  // Parse reference string
  const pages = referenceString
    .split(/[\s,]+/)
    .map(s => s.trim())
    .filter(s => s)
    .map(s => parseInt(s, 10))
    .filter(n => !isNaN(n));

  if (pages.length === 0) {
    throw new Error('Invalid reference string');
  }

  const tlb: number[] = [];
  const accessDetails: AccessDetail[] = [];
  let hits = 0;
  let misses = 0;

  pages.forEach((page, index) => {
    const tlbIndex = tlb.indexOf(page);
    const isHit = tlbIndex !== -1;

    if (isHit) {
      hits++;
      // For LRU, move accessed page to the end (most recently used)
      if (replacementPolicy === 'LRU') {
        tlb.splice(tlbIndex, 1);
        tlb.push(page);
      }
    } else {
      misses++;
      if (tlb.length < tlbSize) {
        // TLB not full, just add
        tlb.push(page);
      } else {
        // TLB full, replace based on policy
        if (replacementPolicy === 'FIFO') {
          tlb.shift(); // Remove first (oldest)
          tlb.push(page);
        } else {
          // LRU - remove first (least recently used)
          tlb.shift();
          tlb.push(page);
        }
      }
    }

    accessDetails.push({
      accessNumber: index + 1,
      pageNumber: page,
      isHit,
    });
  });

  const totalAccesses = pages.length;
  const hitRate = (hits / totalAccesses) * 100;
  const missRate = (misses / totalAccesses) * 100;

  // EMAT = TLB hit rate × TLB access time + TLB miss rate × (TLB access time + Memory access time)
  const emat = (hitRate / 100) * tlbAccessTime + (missRate / 100) * (tlbAccessTime + memoryAccessTime);

  return {
    config,
    hitRate,
    missRate,
    emat,
    totalAccesses,
    hits,
    misses,
    accessDetails,
  };
}
