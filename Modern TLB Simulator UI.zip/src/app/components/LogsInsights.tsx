import { useState } from 'react';
import { Search, Download, Trash2, ArrowLeft, Lightbulb } from 'lucide-react';
import { SimulationLog } from '../types';

interface LogsInsightsProps {
  logs: SimulationLog[];
  onClearLogs: () => void;
  onExportLogs: () => void;
  onBackToLanding: () => void;
}

export default function LogsInsights({ logs, onClearLogs, onExportLogs, onBackToLanding }: LogsInsightsProps) {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLogs = logs.filter(log =>
    log.id.includes(searchTerm) ||
    log.config.tlbSize.toString().includes(searchTerm) ||
    log.config.replacementPolicy.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const insights = [
    'Higher locality of reference leads to better hit rates',
    'Increasing TLB size generally improves performance',
    'LRU policy performs better with temporal locality patterns',
    'FIFO policy is simpler but may not adapt to access patterns',
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)] px-4 py-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl text-white">Logs & Insights</h1>
          <button
            onClick={onBackToLanding}
            className="px-4 py-2 backdrop-blur-xl bg-white/10 border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Logs Table */}
          <div className="lg:col-span-2">
            <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl shadow-xl overflow-hidden">
              {/* Search and Actions */}
              <div className="p-6 border-b border-white/20">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
                    <input
                      type="text"
                      placeholder="Search by ID, size, or policy..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/30 rounded-xl text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-purple-400"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={onExportLogs}
                      disabled={logs.length === 0}
                      className="px-4 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl hover:from-blue-600 hover:to-purple-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      Export CSV
                    </button>
                    <button
                      onClick={onClearLogs}
                      disabled={logs.length === 0}
                      className="px-4 py-3 bg-red-500/20 text-red-300 border border-red-500/30 rounded-xl hover:bg-red-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      <Trash2 className="w-4 h-4" />
                      Clear Logs
                    </button>
                  </div>
                </div>
              </div>

              {/* Table */}
              <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
                {filteredLogs.length === 0 ? (
                  <div className="p-12 text-center">
                    <p className="text-white/60">
                      {logs.length === 0 ? 'No simulation logs yet. Run a simulation to see results here.' : 'No logs match your search.'}
                    </p>
                  </div>
                ) : (
                  <table className="w-full">
                    <thead className="sticky top-0 backdrop-blur-xl bg-white/10">
                      <tr className="border-b border-white/20">
                        <th className="px-6 py-4 text-left text-white/70">ID</th>
                        <th className="px-6 py-4 text-left text-white/70">TLB Size</th>
                        <th className="px-6 py-4 text-left text-white/70">Memory (ns)</th>
                        <th className="px-6 py-4 text-left text-white/70">TLB (ns)</th>
                        <th className="px-6 py-4 text-left text-white/70">Policy</th>
                        <th className="px-6 py-4 text-left text-white/70">Hit Rate</th>
                        <th className="px-6 py-4 text-left text-white/70">EMAT</th>
                        <th className="px-6 py-4 text-left text-white/70">Timestamp</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredLogs.map((log) => (
                        <tr
                          key={log.id}
                          className="border-b border-white/10 hover:bg-white/5 transition-colors"
                        >
                          <td className="px-6 py-4 text-white/80 font-mono text-sm">
                            {log.id.slice(-6)}
                          </td>
                          <td className="px-6 py-4 text-white">{log.config.tlbSize}</td>
                          <td className="px-6 py-4 text-white">{log.config.memoryAccessTime}</td>
                          <td className="px-6 py-4 text-white">{log.config.tlbAccessTime}</td>
                          <td className="px-6 py-4">
                            <span className={`px-3 py-1 rounded-full inline-block ${
                              log.config.replacementPolicy === 'FIFO'
                                ? 'bg-blue-500/20 text-blue-300'
                                : 'bg-purple-500/20 text-purple-300'
                            }`}>
                              {log.config.replacementPolicy}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-3 py-1 rounded-full inline-block ${
                              log.hitRate >= 70
                                ? 'bg-green-500/20 text-green-300'
                                : log.hitRate >= 40
                                ? 'bg-yellow-500/20 text-yellow-300'
                                : 'bg-red-500/20 text-red-300'
                            }`}>
                              {log.hitRate.toFixed(1)}%
                            </span>
                          </td>
                          <td className="px-6 py-4 text-white">{log.emat.toFixed(2)}</td>
                          <td className="px-6 py-4 text-white/60 text-sm">
                            {new Date(log.timestamp).toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          </div>

          {/* Insights Panel */}
          <div className="lg:col-span-1">
            <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl shadow-xl p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="p-3 bg-yellow-500/20 rounded-xl">
                  <Lightbulb className="w-6 h-6 text-yellow-400" />
                </div>
                <h3 className="text-xl text-white">Insights</h3>
              </div>

              <div className="space-y-4">
                {insights.map((insight, index) => (
                  <div
                    key={index}
                    className="p-4 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all"
                  >
                    <p className="text-white/80">{insight}</p>
                  </div>
                ))}
              </div>

              {/* Stats Summary */}
              {logs.length > 0 && (
                <div className="mt-6 p-4 bg-gradient-to-br from-purple-500/20 to-blue-500/20 border border-purple-400/30 rounded-xl">
                  <h4 className="text-white mb-3">Summary</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between text-white/70">
                      <span>Total Simulations:</span>
                      <span className="text-white">{logs.length}</span>
                    </div>
                    <div className="flex justify-between text-white/70">
                      <span>Avg Hit Rate:</span>
                      <span className="text-white">
                        {(logs.reduce((sum, log) => sum + log.hitRate, 0) / logs.length).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex justify-between text-white/70">
                      <span>Avg EMAT:</span>
                      <span className="text-white">
                        {(logs.reduce((sum, log) => sum + log.emat, 0) / logs.length).toFixed(2)} ns
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
