import { useEffect, useState } from 'react';
import { Loader2, Cpu, Database, HardDrive, CheckCircle2, Clock } from 'lucide-react';

export default function SimulationRunning() {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    { label: 'Input Received', icon: CheckCircle2, status: 'completed' },
    { label: 'TLB Lookup', icon: Cpu, status: 'in-progress' },
    { label: 'Memory Access', icon: HardDrive, status: 'pending' },
    { label: 'Final Calculation', icon: Database, status: 'pending' },
  ];

  useEffect(() => {
    const intervals = [0, 800, 1600, 2400];
    intervals.forEach((delay, index) => {
      setTimeout(() => setCurrentStep(index), delay);
    });
  }, []);

  const getStepStatus = (index: number) => {
    if (index < currentStep) return 'completed';
    if (index === currentStep) return 'in-progress';
    return 'pending';
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col items-center justify-center px-4">
      {/* Center Loader */}
      <div className="mb-12 text-center animate-fade-in">
        <div className="relative inline-block mb-6">
          <div className="w-24 h-24 rounded-full border-4 border-white/20 border-t-purple-400 animate-spin" />
          <div className="absolute inset-0 flex items-center justify-center">
            <Loader2 className="w-12 h-12 text-purple-400" />
          </div>
        </div>
        <h2 className="text-3xl text-white mb-2">Running Simulation...</h2>
        <p className="text-lg text-white/70">Checking TLB → Accessing Memory → Updating Cache</p>
      </div>

      {/* Step Progress */}
      <div className="w-full max-w-3xl backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl shadow-2xl p-8">
        <div className="space-y-4">
          {steps.map((step, index) => {
            const status = getStepStatus(index);
            const StepIcon = step.icon;

            return (
              <div
                key={index}
                className={`flex items-center gap-4 p-4 rounded-xl transition-all duration-500 ${
                  status === 'completed'
                    ? 'bg-green-500/20 border border-green-400/30'
                    : status === 'in-progress'
                    ? 'bg-purple-500/20 border border-purple-400/30 animate-pulse'
                    : 'bg-white/5 border border-white/10'
                }`}
              >
                <div
                  className={`p-3 rounded-lg ${
                    status === 'completed'
                      ? 'bg-green-500/30 text-green-300'
                      : status === 'in-progress'
                      ? 'bg-purple-500/30 text-purple-300'
                      : 'bg-white/10 text-white/40'
                  }`}
                >
                  <StepIcon className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <p
                    className={`${
                      status === 'completed'
                        ? 'text-green-300'
                        : status === 'in-progress'
                        ? 'text-purple-300'
                        : 'text-white/50'
                    }`}
                  >
                    Step {index + 1}: {step.label}
                  </p>
                </div>
                {status === 'completed' && (
                  <CheckCircle2 className="w-5 h-5 text-green-400" />
                )}
                {status === 'in-progress' && (
                  <Clock className="w-5 h-5 text-purple-400 animate-spin" />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Animated Flow Diagram */}
      <div className="mt-12 w-full max-w-4xl">
        <div className="flex items-center justify-center gap-4">
          <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-2xl p-6 text-center animate-pulse">
            <Cpu className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <p className="text-white/80">CPU</p>
          </div>

          <div className="flex-1 h-1 bg-gradient-to-r from-blue-400 to-purple-400 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent animate-shimmer" />
          </div>

          <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-2xl p-6 text-center animate-pulse">
            <Database className="w-8 h-8 text-purple-400 mx-auto mb-2" />
            <p className="text-white/80">TLB</p>
          </div>

          <div className="flex-1 h-1 bg-gradient-to-r from-purple-400 to-pink-400 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent animate-shimmer animation-delay-200" />
          </div>

          <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-2xl p-6 text-center animate-pulse">
            <HardDrive className="w-8 h-8 text-pink-400 mx-auto mb-2" />
            <p className="text-white/80">Memory</p>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        .animate-shimmer {
          animation: shimmer 1.5s infinite;
        }
        .animation-delay-200 {
          animation-delay: 0.2s;
        }
      `}</style>
    </div>
  );
}
