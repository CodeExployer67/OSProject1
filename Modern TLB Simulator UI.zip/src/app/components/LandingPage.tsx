import { useState } from 'react';
import { PlayCircle } from 'lucide-react';
import { SimulationConfig } from '../types';

interface LandingPageProps {
  onStartSimulation: (config: SimulationConfig) => void;
}

export default function LandingPage({ onStartSimulation }: LandingPageProps) {
  const [tlbSize, setTlbSize] = useState('4');
  const [memoryAccessTime, setMemoryAccessTime] = useState('100');
  const [tlbAccessTime, setTlbAccessTime] = useState('10');
  const [referenceString, setReferenceString] = useState('1 2 3 4 1 2 5 1 2 3 4 5');
  const [replacementPolicy, setReplacementPolicy] = useState<'FIFO' | 'LRU'>('FIFO');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};

    const tlbSizeNum = parseInt(tlbSize, 10);
    if (isNaN(tlbSizeNum) || tlbSizeNum < 1 || tlbSizeNum > 64) {
      newErrors.tlbSize = 'TLB Size must be between 1 and 64';
    }

    const memTimeNum = parseInt(memoryAccessTime, 10);
    if (isNaN(memTimeNum) || memTimeNum < 1) {
      newErrors.memoryAccessTime = 'Memory Access Time must be positive';
    }

    const tlbTimeNum = parseInt(tlbAccessTime, 10);
    if (isNaN(tlbTimeNum) || tlbTimeNum < 1) {
      newErrors.tlbAccessTime = 'TLB Access Time must be positive';
    }

    const pages = referenceString
      .split(/[\s,]+/)
      .filter(s => s.trim())
      .map(s => parseInt(s.trim(), 10));

    if (pages.length === 0 || pages.some(isNaN)) {
      newErrors.referenceString = 'Please enter valid page numbers separated by spaces or commas';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onStartSimulation({
        tlbSize: parseInt(tlbSize, 10),
        memoryAccessTime: parseInt(memoryAccessTime, 10),
        tlbAccessTime: parseInt(tlbAccessTime, 10),
        referenceString,
        replacementPolicy,
      });
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col items-center justify-center px-4 py-12">
      {/* Hero Section */}
      <div className="text-center mb-12 animate-fade-in">
        <h1 className="text-5xl text-white mb-4">
          Understand Memory Optimization with TLB Simulation
        </h1>
        <p className="text-xl text-white/80 max-w-3xl mx-auto">
          Analyze hit rates, memory access time, and caching performance in real time
        </p>
      </div>

      {/* Main Card */}
      <div className="w-full max-w-2xl backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl shadow-2xl p-8 animate-scale-in">
        <h2 className="text-3xl text-white mb-6">Start Simulation</h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* TLB Size */}
          <div className="relative">
            <input
              type="number"
              id="tlbSize"
              value={tlbSize}
              onChange={(e) => setTlbSize(e.target.value)}
              className="w-full px-4 pt-6 pb-2 bg-white/5 border border-white/30 rounded-xl text-white placeholder-transparent focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all peer"
              placeholder="TLB Size"
            />
            <label
              htmlFor="tlbSize"
              className="absolute left-4 top-2 text-xs text-white/60 transition-all peer-placeholder-shown:top-4 peer-placeholder-shown:text-base peer-placeholder-shown:text-white/40 peer-focus:top-2 peer-focus:text-xs peer-focus:text-purple-300"
            >
              TLB Size
            </label>
            {errors.tlbSize && (
              <p className="mt-1 text-sm text-red-300">{errors.tlbSize}</p>
            )}
          </div>

          {/* Memory Access Time */}
          <div className="relative">
            <input
              type="number"
              id="memoryAccessTime"
              value={memoryAccessTime}
              onChange={(e) => setMemoryAccessTime(e.target.value)}
              className="w-full px-4 pt-6 pb-2 bg-white/5 border border-white/30 rounded-xl text-white placeholder-transparent focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all peer"
              placeholder="Memory Access Time (ns)"
            />
            <label
              htmlFor="memoryAccessTime"
              className="absolute left-4 top-2 text-xs text-white/60 transition-all peer-placeholder-shown:top-4 peer-placeholder-shown:text-base peer-placeholder-shown:text-white/40 peer-focus:top-2 peer-focus:text-xs peer-focus:text-purple-300"
            >
              Memory Access Time (ns)
            </label>
            {errors.memoryAccessTime && (
              <p className="mt-1 text-sm text-red-300">{errors.memoryAccessTime}</p>
            )}
          </div>

          {/* TLB Access Time */}
          <div className="relative">
            <input
              type="number"
              id="tlbAccessTime"
              value={tlbAccessTime}
              onChange={(e) => setTlbAccessTime(e.target.value)}
              className="w-full px-4 pt-6 pb-2 bg-white/5 border border-white/30 rounded-xl text-white placeholder-transparent focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all peer"
              placeholder="TLB Access Time (ns)"
            />
            <label
              htmlFor="tlbAccessTime"
              className="absolute left-4 top-2 text-xs text-white/60 transition-all peer-placeholder-shown:top-4 peer-placeholder-shown:text-base peer-placeholder-shown:text-white/40 peer-focus:top-2 peer-focus:text-xs peer-focus:text-purple-300"
            >
              TLB Access Time (ns)
            </label>
            {errors.tlbAccessTime && (
              <p className="mt-1 text-sm text-red-300">{errors.tlbAccessTime}</p>
            )}
          </div>

          {/* Reference String */}
          <div className="relative">
            <textarea
              id="referenceString"
              value={referenceString}
              onChange={(e) => setReferenceString(e.target.value)}
              rows={3}
              className="w-full px-4 pt-6 pb-2 bg-white/5 border border-white/30 rounded-xl text-white placeholder-transparent focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all peer resize-none"
              placeholder="Reference String"
            />
            <label
              htmlFor="referenceString"
              className="absolute left-4 top-2 text-xs text-white/60"
            >
              Reference String
            </label>
            {errors.referenceString && (
              <p className="mt-1 text-sm text-red-300">{errors.referenceString}</p>
            )}
          </div>

          {/* Replacement Policy */}
          <div className="relative">
            <select
              id="replacementPolicy"
              value={replacementPolicy}
              onChange={(e) => setReplacementPolicy(e.target.value as 'FIFO' | 'LRU')}
              className="w-full px-4 pt-6 pb-2 bg-white/5 border border-white/30 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all appearance-none cursor-pointer"
            >
              <option value="FIFO" className="bg-gray-800">FIFO (First In First Out)</option>
              <option value="LRU" className="bg-gray-800">LRU (Least Recently Used)</option>
            </select>
            <label
              htmlFor="replacementPolicy"
              className="absolute left-4 top-2 text-xs text-white/60"
            >
              Replacement Policy
            </label>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-purple-500 to-blue-500 text-white py-4 rounded-xl hover:from-purple-600 hover:to-blue-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-[1.02] flex items-center justify-center gap-2 mt-8"
          >
            <PlayCircle className="w-5 h-5" />
            Run Simulation
          </button>
        </form>
      </div>
    </div>
  );
}
