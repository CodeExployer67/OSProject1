import { BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { TrendingUp, TrendingDown, Clock, ArrowLeft, FileText } from 'lucide-react';
import { SimulationResult } from '../types';

interface ResultsDashboardProps {
  result: SimulationResult;
  onBackToLanding: () => void;
  onViewLogs: () => void;
}

export default function ResultsDashboard({ result, onBackToLanding, onViewLogs }: ResultsDashboardProps) {
  const { hitRate, missRate, emat, hits, misses, accessDetails } = result;

  const barData = [
    { name: 'Hits', value: hits, color: '#10b981' },
    { name: 'Misses', value: misses, color: '#ef4444' },
  ];

  const pieData = [
    { name: 'Hit Rate', value: hitRate, color: '#10b981' },
    { name: 'Miss Rate', value: missRate, color: '#ef4444' },
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)] px-4 py-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl text-white">Simulation Results</h1>
          <div className="flex gap-3">
            <button
              onClick={onViewLogs}
              className="px-4 py-2 backdrop-blur-xl bg-white/10 border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all flex items-center gap-2"
            >
              <FileText className="w-4 h-4" />
              View Logs
            </button>
            <button
              onClick={onBackToLanding}
              className="px-4 py-2 backdrop-blur-xl bg-white/10 border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              New Simulation
            </button>
          </div>
        </div>

        {/* Top Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* TLB Hit Rate */}
          <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl p-6 shadow-xl">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-white/70 mb-1">TLB Hit Rate</p>
                <h3 className="text-4xl text-white">{hitRate.toFixed(2)}%</h3>
              </div>
              <div className="p-3 bg-green-500/20 rounded-xl">
                <TrendingUp className="w-6 h-6 text-green-400" />
              </div>
            </div>
            <div className="text-green-400 flex items-center gap-1">
              <span className="text-sm">{hits} hits out of {hits + misses} accesses</span>
            </div>
          </div>

          {/* TLB Miss Rate */}
          <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl p-6 shadow-xl">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-white/70 mb-1">TLB Miss Rate</p>
                <h3 className="text-4xl text-white">{missRate.toFixed(2)}%</h3>
              </div>
              <div className="p-3 bg-red-500/20 rounded-xl">
                <TrendingDown className="w-6 h-6 text-red-400" />
              </div>
            </div>
            <div className="text-red-400 flex items-center gap-1">
              <span className="text-sm">{misses} misses out of {hits + misses} accesses</span>
            </div>
          </div>

          {/* EMAT */}
          <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl p-6 shadow-xl">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-white/70 mb-1">Effective Memory Access Time</p>
                <h3 className="text-4xl text-white">{emat.toFixed(2)}</h3>
              </div>
              <div className="p-3 bg-blue-500/20 rounded-xl">
                <Clock className="w-6 h-6 text-blue-400" />
              </div>
            </div>
            <div className="text-blue-400 flex items-center gap-1">
              <span className="text-sm">nanoseconds (ns)</span>
            </div>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Bar Chart */}
          <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl p-6 shadow-xl">
            <h3 className="text-xl text-white mb-6">Hits vs Misses</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={barData}>
                <XAxis dataKey="name" stroke="#ffffff80" />
                <YAxis stroke="#ffffff80" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    border: '1px solid rgba(255, 255, 255, 0.2)',
                    borderRadius: '12px',
                    color: '#fff',
                  }}
                />
                <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                  {barData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Pie Chart */}
          <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl p-6 shadow-xl">
            <h3 className="text-xl text-white mb-6">Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value.toFixed(1)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    border: '1px solid rgba(255, 255, 255, 0.2)',
                    borderRadius: '12px',
                    color: '#fff',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Access Details Table */}
        <div className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl shadow-xl overflow-hidden">
          <div className="p-6 border-b border-white/20">
            <h3 className="text-xl text-white">Access Details</h3>
          </div>
          <div className="overflow-x-auto max-h-96 overflow-y-auto">
            <table className="w-full">
              <thead className="sticky top-0 backdrop-blur-xl bg-white/10">
                <tr className="border-b border-white/20">
                  <th className="px-6 py-4 text-left text-white/70">Access #</th>
                  <th className="px-6 py-4 text-left text-white/70">Page Number</th>
                  <th className="px-6 py-4 text-left text-white/70">Result</th>
                </tr>
              </thead>
              <tbody>
                {accessDetails.map((detail) => (
                  <tr
                    key={detail.accessNumber}
                    className="border-b border-white/10 hover:bg-white/5 transition-colors"
                  >
                    <td className="px-6 py-4 text-white">{detail.accessNumber}</td>
                    <td className="px-6 py-4 text-white">{detail.pageNumber}</td>
                    <td className="px-6 py-4">
                      {detail.isHit ? (
                        <span className="px-3 py-1 bg-green-500/20 text-green-300 rounded-full inline-block">
                          Hit
                        </span>
                      ) : (
                        <span className="px-3 py-1 bg-red-500/20 text-red-300 rounded-full inline-block">
                          Miss
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
