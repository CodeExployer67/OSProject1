import { useState } from 'react';
import { Cpu } from 'lucide-react';
import LandingPage from './components/LandingPage';
import SimulationRunning from './components/SimulationRunning';
import ResultsDashboard from './components/ResultsDashboard';
import LogsInsights from './components/LogsInsights';
import { SimulationConfig, SimulationResult, SimulationLog } from './types';
import { runSimulation } from './utils/tlbSimulator';

type Screen = 'landing' | 'running' | 'results' | 'logs';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('landing');
  const [currentResult, setCurrentResult] = useState<SimulationResult | null>(null);
  const [simulationLogs, setSimulationLogs] = useState<SimulationLog[]>([]);

  const handleStartSimulation = (config: SimulationConfig) => {
    setCurrentScreen('running');

    // Simulate processing time
    setTimeout(() => {
      const result = runSimulation(config);
      const log: SimulationLog = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        config,
        hitRate: result.hitRate,
        emat: result.emat,
      };

      setCurrentResult(result);
      setSimulationLogs(prev => [log, ...prev]);
      setCurrentScreen('results');
    }, 3000);
  };

  const handleBackToLanding = () => {
    setCurrentScreen('landing');
  };

  const handleViewLogs = () => {
    setCurrentScreen('logs');
  };

  const handleClearLogs = () => {
    setSimulationLogs([]);
  };

  const handleExportLogs = () => {
    const csvContent = [
      ['Simulation ID', 'TLB Size', 'Memory Time (ns)', 'TLB Time (ns)', 'Policy', 'Hit Rate (%)', 'EMAT (ns)', 'Timestamp'],
      ...simulationLogs.map(log => [
        log.id,
        log.config.tlbSize,
        log.config.memoryAccessTime,
        log.config.tlbAccessTime,
        log.config.replacementPolicy,
        log.hitRate.toFixed(2),
        log.emat.toFixed(2),
        new Date(log.timestamp).toLocaleString(),
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'tlb-simulation-logs.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-blue-600 to-blue-800 overflow-hidden">
      {/* Navigation Bar */}
      <nav className="backdrop-blur-md bg-white/10 border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-gradient-to-br from-purple-400 to-blue-500 rounded-lg">
                <Cpu className="w-6 h-6 text-white" />
              </div>
              <span className="text-white font-semibold">TLB Simulator</span>
            </div>
            <div className="flex gap-6">
              <button
                onClick={handleBackToLanding}
                className={`text-white/90 hover:text-white transition-colors ${currentScreen === 'landing' ? 'text-white font-medium' : ''}`}
              >
                Home
              </button>
              <button
                onClick={handleBackToLanding}
                className={`text-white/90 hover:text-white transition-colors ${currentScreen === 'running' || currentScreen === 'results' ? 'text-white font-medium' : ''}`}
              >
                Simulator
              </button>
              <button
                onClick={() => currentResult && setCurrentScreen('results')}
                className={`text-white/90 hover:text-white transition-colors ${currentScreen === 'results' ? 'text-white font-medium' : ''} ${!currentResult ? 'opacity-50 cursor-not-allowed' : ''}`}
                disabled={!currentResult}
              >
                Results
              </button>
              <button
                onClick={handleViewLogs}
                className={`text-white/90 hover:text-white transition-colors ${currentScreen === 'logs' ? 'text-white font-medium' : ''}`}
              >
                Logs
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Content */}
      <div className="relative">
        {currentScreen === 'landing' && (
          <LandingPage onStartSimulation={handleStartSimulation} />
        )}

        {currentScreen === 'running' && (
          <SimulationRunning />
        )}

        {currentScreen === 'results' && currentResult && (
          <ResultsDashboard
            result={currentResult}
            onBackToLanding={handleBackToLanding}
            onViewLogs={handleViewLogs}
          />
        )}

        {currentScreen === 'logs' && (
          <LogsInsights
            logs={simulationLogs}
            onClearLogs={handleClearLogs}
            onExportLogs={handleExportLogs}
            onBackToLanding={handleBackToLanding}
          />
        )}
      </div>
    </div>
  );
}
